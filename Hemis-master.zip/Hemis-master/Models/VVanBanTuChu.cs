﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VVanBanTuChu
{
    public string? LoaiVanBan { get; set; }

    public string? NoiDungVanBan { get; set; }

    public string? QuyetDinhBanHanh { get; set; }

    public string? CoQuanQuyetDinhBanHanh { get; set; }
}
