﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VDoiTuongThamGium
{
    public string? LoaiThamGia { get; set; }

    public string? MaLoaiThamGia { get; set; }

    public string? SoCccd { get; set; }

    public string? VaiTroThamGia { get; set; }

    public string? PhanLoaiDoiNguNguoiHoc { get; set; }
}
