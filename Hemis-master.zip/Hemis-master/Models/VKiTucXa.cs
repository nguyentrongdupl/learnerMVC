﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VKiTucXa
{
    public string? MaKyTucxa { get; set; }

    public string? HinhThucSoHuu { get; set; }

    public int? TongChoO { get; set; }

    public double? TongDienTich { get; set; }

    public string? TinhTrangCoSoVatChat { get; set; }

    public int? SoPhong { get; set; }

    public string? NamDuaVaoSuDung { get; set; }
}
