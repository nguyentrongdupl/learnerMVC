﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VDoanhNghiepKhcn
{
    public string? MaDoanhNghiep { get; set; }

    public string? TenDoanhNghiep { get; set; }

    public string? HinhThucDoanhNghiepKhcn { get; set; }

    public string? DiaDiemThanhLap { get; set; }

    public int? QuyMoDauTu { get; set; }

    public string? KinhPhiGopVonTuTaiSanTriTue { get; set; }

    public int? TyLeGopVonCuaCsgddh { get; set; }
}
