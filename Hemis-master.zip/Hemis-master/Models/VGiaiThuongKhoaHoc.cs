﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VGiaiThuongKhoaHoc
{
    public string? MaGiaiThuong { get; set; }

    public string? LoaiGiaiThuongKhcn { get; set; }

    public string? CoQuanToChucGiaiThuong { get; set; }

    public string? TenDeTaiDuocTraoGiai { get; set; }

    public string? TenDonViDuocTraoGiai { get; set; }

    public string? MucGiaiThuong { get; set; }

    public string? QuyetDinhCapBangKhen { get; set; }

    public string? CoQuanBanHanhQuyetDinh { get; set; }
}
