﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VDanhHieuThiDuaGiaiThuongKhenThuongCuaCoSoGd
{
    public string? ThiDuaGiaiThuongKhenThuong { get; set; }

    public string? LoaiDanhHieuThiDuaGiaiThuongKhenThuong { get; set; }

    public string? SoQuyetDinhKhenThuong { get; set; }

    public string? PhuongThucKhenThuong { get; set; }

    public string? NamKhenThuong { get; set; }

    public string? CapKhenThuong { get; set; }
}
