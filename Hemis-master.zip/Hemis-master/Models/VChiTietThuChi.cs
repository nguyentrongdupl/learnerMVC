﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VChiTietThuChi
{
    public string? MaLoaiThuChi { get; set; }

    public string? TenKhoanThuChi { get; set; }

    public string? NamTaiChinh { get; set; }

    public int? SoTien { get; set; }
}
