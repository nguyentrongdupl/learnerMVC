﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmPhanLoaiHoiNghiHoiThao
{
    public int IdPhanLoaiHoiNghiHoiThao { get; set; }

    public string? PhanLoaiHoiNghiHoiThao { get; set; }
}
