﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmTrinhDo
{
    public int IdTrinhDo { get; set; }

    public string? TrinhDo { get; set; }
}
