﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmCoQuanBanHanh
{
    public int IdCoQuanBanHanh { get; set; }

    public string? CoQuanBanHanh { get; set; }
}
