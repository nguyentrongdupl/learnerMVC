﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmLoaiToChuc
{
    public int IdLoaiToChuc { get; set; }

    public string? LoaiToChuc { get; set; }
}
