﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmPhanLoaiDoiTuong
{
    public int IdPhanLoaiDoiTuong { get; set; }

    public string? PhanLoaiDoiTuong { get; set; }
}
