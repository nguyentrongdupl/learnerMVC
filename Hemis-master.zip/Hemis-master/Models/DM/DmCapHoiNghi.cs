﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmCapHoiNghi
{
    public int IdCapHoiNghi { get; set; }

    public string? CapHoiNghi { get; set; }
}
