﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmDanhHieuVinhDuGiaiThuong
{
    public int IdDanhHieuVinhDuGiaiThuong { get; set; }

    public string? DanhHieuVinhDuGiaiThuong { get; set; }
}
