﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models.DM;

public partial class DmLoaiHocVien
{
    public int IdLoaiHocVien { get; set; }

    public string? LoaiHocVien { get; set; }
}
