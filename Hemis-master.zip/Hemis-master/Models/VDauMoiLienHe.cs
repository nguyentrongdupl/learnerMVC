﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VDauMoiLienHe
{
    public string? DauMoiLienHe { get; set; }

    public string? SoDienThoai { get; set; }

    public string? Email { get; set; }
}
