﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VNhomNganhDaoTao
{
    public string? LinhVucDaoTao { get; set; }

    public string? NhomNganh { get; set; }

    public string? NganhDaoTao { get; set; }
}
