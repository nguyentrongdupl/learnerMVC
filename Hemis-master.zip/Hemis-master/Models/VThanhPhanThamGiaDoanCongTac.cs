﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VThanhPhanThamGiaDoanCongTac
{
    public string? MaDoanCongTac { get; set; }

    public string? MaCanBo { get; set; }

    public string? VaiTroThamGia { get; set; }
}
