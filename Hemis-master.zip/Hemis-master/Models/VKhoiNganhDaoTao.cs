﻿using System;
using System.Collections.Generic;

namespace C500Hemis.Models;

public partial class VKhoiNganhDaoTao
{
    public string? KhoiNganhDaoTao { get; set; }
}
